package com.capgemini.bank.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.Dao.BankApplicationDAO;
import com.capgemini.bank.Dao.BankApplicationDAOImpl;
import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exceptions.BankException;

public class BankApplicationServiceImpl implements BankApplicationService {
	BankApplicationDAO accountDAO = new BankApplicationDAOImpl();

	@Override
	public int createAccount(Customer customer) throws BankException {
		return accountDAO.createAccount(customer);
	}

	@Override
	public double showBalance(int accountno) throws BankException {
		return accountDAO.showBalance(accountno);
	}

	@Override
	public List<Transaction> deposit(int accountno, double amount) throws BankException {
		return accountDAO.deposit(accountno, amount);
	}

	@Override
	public List<Transaction> withdraw(int accountno, double amount) throws BankException {
		return accountDAO.withdraw(accountno, amount);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountno, int destinationAccountNo, double amount)
			throws BankException {
		return accountDAO.fundTransfer(sourceAccountno, destinationAccountNo, amount);
	}

	@Override
	public List<Transaction> printTransactions(int accountno) throws BankException {
		return accountDAO.printTransactions(accountno);
	}

	@Override
	public boolean isNameValid(String name) throws BankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean isMailValid(String mail) throws BankException {
		Pattern mailPattern = Pattern.compile("[A-Za-z][@gmail.com]");
		Matcher matcher = mailPattern.matcher(mail);
		if (matcher.matches())
			throw new BankException("Invalid mail ID");
		else
			return false;
	}

	@Override
	public boolean isMobileValid(String mobile) throws BankException {
		String input1 = String.valueOf(mobile);
		Pattern mobilePattern = Pattern.compile("[7,8,9]{1}[0-9]{9}");
		Matcher matcher = mobilePattern.matcher(input1);
		if (matcher.matches())
			return true;
		else
			return false;
	}

	@Override
	public boolean isAddressValid(String address) throws BankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, address)) {
			throw new BankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

}
