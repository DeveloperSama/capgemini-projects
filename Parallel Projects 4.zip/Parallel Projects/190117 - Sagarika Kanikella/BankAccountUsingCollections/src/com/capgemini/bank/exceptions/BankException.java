package com.capgemini.bank.exceptions;

@SuppressWarnings("serial")
public class BankException extends Exception{
	public BankException(String message) {
		super(message);
	}

}
