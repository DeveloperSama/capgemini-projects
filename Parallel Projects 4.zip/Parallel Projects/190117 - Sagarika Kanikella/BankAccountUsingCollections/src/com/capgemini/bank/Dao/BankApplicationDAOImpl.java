package com.capgemini.bank.Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.utility.AccountRepositories;

public class BankApplicationDAOImpl implements BankApplicationDAO {
	static Map<Integer, Customer> map = new HashMap<>();

	@Override
	public int createAccount(Customer customer) {
		map.putAll(AccountRepositories.getCustomers());
		int accountNo = (int) (Math.random() * 1000);
		customer.setAccountNo(accountNo);
		map.put(accountNo, customer);
		return accountNo;
	}

	@Override
	public double showBalance(int accountno) {
		map.putAll(AccountRepositories.getCustomers());
		double balance = 0;
		boolean status = map.containsKey(accountno);
		if (status == false) {
			try {
				throw new Exception("Account Number is not listed...");
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Customer customer = map.get(accountno);
			balance = customer.getBalance();
		}
		return balance;
	}

	@Override
	public List<Transaction> deposit(int accountno, double amount) {
		map.putAll(AccountRepositories.getCustomers());
		int transactionId = (int) (Math.random() * 1000);
		List<Transaction> transactionList = new ArrayList<>();
		Customer customer = map.get(accountno);
		double balance = customer.getBalance() + amount;
		String date = java.time.LocalDate.now().toString();
		Transaction transaction = new Transaction(accountno, transactionId, "Deposit", date, balance);
		transactionList.add(transaction);
		customer.setBalance(balance);
		printTransaction.add(transaction);
		return transactionList;

	}

	@Override
	public List<Transaction> withdraw(int accountno, double amount) {
		map.putAll(AccountRepositories.getCustomers());
		int transactionId = (int) (Math.random() * 1000);
		List<Transaction> transactionList = new ArrayList<>();
		Customer customer = map.get(accountno);
		double balance = customer.getBalance() - amount;
		try {
			if (amount > balance) {
				throw new BankException("Insufficient balance! Withdraw cannot be done \n");
			} else
				balance = customer.getBalance() - amount;
		} catch (BankException n) {
			System.out.print(n.getMessage());
		}
		String date = java.time.LocalDate.now().toString();
		Transaction transaction = new Transaction(accountno, transactionId, "Withdraw", date, balance);
		transactionList.add(transaction);
		customer.setBalance(balance);
		printTransaction.add(transaction);
		return transactionList;
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountNo, int destinationAccountNo, double amount) {
		map.putAll(AccountRepositories.getCustomers());
		int transactionId = (int) (Math.random() * 1000);
		List<Transaction> transactionList = new ArrayList<>();
		Customer customer = map.get(sourceAccountNo);
		double balance = customer.getBalance() - amount;

		try {
			if (amount > balance) {
				throw new BankException("Insufficient balance! Withdraw cannot be done \n");
			} else
				balance = customer.getBalance() - amount;
		} catch (BankException n) {
			System.out.print(n.getMessage());
		}
		String date = java.time.LocalDate.now().toString();
		Transaction transaction = new Transaction(sourceAccountNo, transactionId, "Deposit", date, balance);
		transactionList.add(transaction);
		Customer customer1 = map.get(destinationAccountNo);
		double balance1 = customer1.getBalance() + amount;
		customer1.setBalance(balance);
		printTransaction.add(transaction);
		return transactionList;
	}

	@Override
	public List<Transaction> printTransactions(int accountno) {
		List<Transaction> transactionList = new ArrayList<>();
		int size = printTransaction.size();
		for (int i = 0; i < size; i++) {
			Transaction transaction = printTransaction.get(i);
			if (transaction.getAccountNo() == accountno)
				transactionList.add(transaction);
		}
		return transactionList;
	}
}
