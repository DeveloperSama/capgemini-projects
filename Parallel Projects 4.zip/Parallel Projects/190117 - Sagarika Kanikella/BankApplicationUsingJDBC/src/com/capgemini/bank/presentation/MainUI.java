package com.capgemini.bank.presentation;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bank.bean.CustomerDetails;
import com.capgemini.bank.bean.TransactionDetails;
import com.capgemini.bank.exception.BankAccountException;
import com.capgemini.bank.service.BankAccountService;
import com.capgemini.bank.service.BankAccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws BankAccountException{
		BankAccountService service = new BankAccountServiceImpl();
		Scanner scanner = null;
		String continueChoice;
		boolean continueValue = false;
		do {
			System.out.println("*** Welcome to Capgemini Bank ***");
			System.out.println("1. Create Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");

			int choice = 0;
			boolean choiceFlag = false;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					boolean nameFlag = false;
					String name = "";
					switch(choice) {
					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name of the customer: ");
							name = scanner.nextLine();
							try {
								service.isNameValid(name);
								nameFlag = true;
							} catch (BankAccountException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						System.out.println("Enter email of the customer: ");
						String email=scanner.nextLine();

						String address = "";
						boolean addressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter address of the customer: ");
							try {
								address = scanner.nextLine();
								service.isAddressValid(address);
								addressFlag = true;
							} catch (BankAccountException e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);
						
						String mobile = "";
						boolean mobileFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile number of the customer: ");
							try {
								address = scanner.nextLine();
								service.isMobileValid(mobile);
								mobileFlag = true;
							} catch (BankAccountException e) {
								mobileFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobileFlag);
						
						double amount = 0;
						boolean amountFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter the intital amount you want to deposit:");
							try {
								amount = scanner.nextDouble();
								service.isAmountValid(amount);
								amountFlag = true;
							} catch (InputMismatchException e) {
								amountFlag = false;
								System.err.println("Price should be in digits");
							} catch (BankAccountException e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!amountFlag);

						scanner.nextLine();
						CustomerDetails customer = new CustomerDetails(0,name,email,address,mobile,0,0);
						try {
							int accountNo = service.createAccount(customer, amount);
							System.out.println("Customer account created successfully with account number: "+accountNo);
						}catch(BankAccountException e) {
							System.err.println(e.getMessage());
						}
						break;
					case 2:{
						System.out.println("Enter your account number: ");
						int accountNo=scanner.nextInt();
						try {
							double balance=service.showBalance(accountNo);
							System.out.println("The balance in your account number is: "+balance);
						} catch (BankAccountException e) {
							e.printStackTrace();
						}
					}
						break;
					case 3:{
						System.out.println("Enter your account number: ");
						int accountNo=scanner.nextInt();
						System.out.println("Enter the amount you want to deposit into your account: ");
						double depositAmount=scanner.nextDouble();
						try {
							List<TransactionDetails> transactionList=service.deposit(accountNo, depositAmount);
							System.out.println(transactionList);
						} catch (BankAccountException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}break;
					case 4:{
						System.out.println("Enter your account number: ");
						int accountNo=scanner.nextInt();
						System.out.println("Enter the amount you want to withdraw from your account: ");
						double withdrawAmount=scanner.nextDouble();
						try {
							List<TransactionDetails> transactionList=service.withdraw(accountNo, withdrawAmount);
							System.out.println(transactionList);
						} catch (BankAccountException e) {
							e.printStackTrace();
						}
					}break;
					
					case 5:{
						System.out.println("Enter the source account number: ");
						int sourceAccountNo=scanner.nextInt();
						System.out.println("Enter the destination account number: ");
						int destinationAccountNo=scanner.nextInt();
						System.out.println("Enter the amount you want to transfer into the destination account: ");
						double transferAmount=scanner.nextDouble();
						try {
							List<TransactionDetails> transactionList=service.fundTransfer(sourceAccountNo, destinationAccountNo, transferAmount);
							System.out.println(transactionList);
						} catch (BankAccountException e) {
							e.printStackTrace();
						}
					}break;
					
					case 6:{
						System.out.println("Enter your account number: ");
						int accountNo=scanner.nextInt();
						try {
							List<TransactionDetails> transactionList=service.PrintTransaction(accountNo);
							System.out.println(transactionList);
						} catch (BankAccountException e) {
							e.printStackTrace();
						}
					}break;
					
					case 7:
						System.out.println("THANK YOU, VISIT AGAIN");
						System.exit(0);
						break;
					default:
						System.out.println("input should be between 1 and 7");
						choiceFlag = false;
						break;
					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("Input should contain only digits");
				}
			} while (!choiceFlag);
			do {
				scanner = new Scanner(System.in);
				System.out.println("Do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("THANK YOU");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
		} while (continueValue);
		scanner.close();
	}
}

