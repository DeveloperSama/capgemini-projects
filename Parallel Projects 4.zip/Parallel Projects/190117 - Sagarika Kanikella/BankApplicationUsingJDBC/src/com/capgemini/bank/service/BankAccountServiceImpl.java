package com.capgemini.bank.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.CustomerDetails;
import com.capgemini.bank.bean.TransactionDetails;
import com.capgemini.bank.dao.BankAccountDAO;
import com.capgemini.bank.dao.BankAccountDAOImpl;
import com.capgemini.bank.exception.BankAccountException;

public class BankAccountServiceImpl implements BankAccountService{

	BankAccountDAO bankDAO = new BankAccountDAOImpl();
	@Override
	public int createAccount(CustomerDetails customerData, double amount) throws BankAccountException {
		
		return bankDAO.createBankAccount(customerData, amount);
	}

	@Override
	public double showBalance(int accountNo) throws BankAccountException {
		
		return bankDAO.showBalance(accountNo);
	}

	@Override
	public List<TransactionDetails> deposit(int accountNo, double amount) throws BankAccountException {
		
		return bankDAO.deposit(accountNo, amount);
	}

	@Override
	public List<TransactionDetails> withdraw(int accountNo, double amount) throws BankAccountException {
		
		return bankDAO.withdraw(accountNo, amount);   
	}

	@Override
	public List<TransactionDetails> fundTransfer(int sourceAccount, int destinationAccount, double amount)
			throws BankAccountException {
		
		return bankDAO.fundTransfer(sourceAccount, destinationAccount, amount);
	}

	@Override
	public List<TransactionDetails> PrintTransaction(int accountNo) throws BankAccountException {
		
		return bankDAO.printTransactions(accountNo);
	}

	@Override
	public boolean isNameValid(String name) throws BankAccountException{
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
				throw new BankAccountException("first letter should be capital and length should be greater than 3");
			
		} else {
			resultFlag = true;
		}
		return resultFlag;
		
	}

	@Override
	public boolean isAddressValid(String address) throws BankAccountException{
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, address)) {
				throw new BankAccountException("first letter should be capital and length should be greater than 3");
			
		} else {
			resultFlag = true;
		}
		return resultFlag;
		
	}

	@Override
	public boolean isMobileValid(String mobile) throws BankAccountException{
		Pattern numberptn = Pattern.compile("^[7,8,9]{1}[0-9]{9}$");

		
			Matcher match = numberptn.matcher(mobile);
			if (match.matches()) {
				return true;
			}
			return false;
		
	}

	@Override
	public boolean isAmountValid(double amount) throws BankAccountException {
		boolean amountFlag = false;

		if (amount < 20) {
			throw new BankAccountException("Amount should not be less than 20");
		} else {
			amountFlag = true;
		}
		return amountFlag;
		
	}
                                       
}
