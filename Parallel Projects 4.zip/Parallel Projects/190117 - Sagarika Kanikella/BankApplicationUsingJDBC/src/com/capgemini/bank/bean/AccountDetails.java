package com.capgemini.bank.bean;

public class AccountDetails {

	private int accountNo;
	private double balance;
	public AccountDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountDetails(int accountNo, double balance) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "AccountDetails [accountNo=" + accountNo + ", balance=" + balance + "]";
	}
	
}
