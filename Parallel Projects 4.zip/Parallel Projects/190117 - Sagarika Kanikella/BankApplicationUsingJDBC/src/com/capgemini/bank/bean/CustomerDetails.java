package com.capgemini.bank.bean;

public class CustomerDetails {

	private int customerId;
	private String name;
	private String email;
	private String mobile;
	private String address;
	private int accountNo;
	private int transactionNo;
	
	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CustomerDetails(int customerId, String name, String email, String mobile, String address, int accountNo,
			int transactionNo) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.accountNo = accountNo;
		this.transactionNo = transactionNo;
	}

	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}

	@Override
	public String toString() {
		return "CustomerDetails [customerId=" + customerId + ", name=" + name + ", email=" + email + ", mobile="
				+ mobile + ", address=" + address + ", accountNo=" + accountNo + ", transactionNo=" + transactionNo
				+ "]";
	}
	
	
}
