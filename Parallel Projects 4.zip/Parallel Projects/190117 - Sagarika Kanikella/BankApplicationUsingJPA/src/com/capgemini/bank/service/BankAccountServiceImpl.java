package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.bean.CustomerDetails;
import com.capgemini.bank.bean.TransactionDetails;
import com.capgemini.bank.dao.BankAccountDAO;
import com.capgemini.bank.dao.BankAccountDAOImpl;
import com.capgemini.bank.exception.BankAccountException;

public class BankAccountServiceImpl implements BankAccountService{

	BankAccountDAO bankDAO = new BankAccountDAOImpl();

	@Override
	public int createAccount(CustomerDetails customer, double amount) throws BankAccountException {
		return bankDAO.createAccount(customer, amount);
	}

	@Override
	public double showBalance(int accountNo) throws BankAccountException {
		return bankDAO.showBalance(accountNo);
	}

	@Override
	public List<TransactionDetails> deposit(int accountNo, double amount) throws BankAccountException {
		return bankDAO.deposit(accountNo, amount);
	}

	@Override
	public List<TransactionDetails> withdraw(int accountNo, double amount) throws BankAccountException {
		return bankDAO.withdraw(accountNo, amount);
	}

	@Override
	public List<TransactionDetails> fundTransfer(int sourceAccount, int destinationAccount, double amount)
			throws BankAccountException {
		return bankDAO.fundTransfer(sourceAccount, destinationAccount, amount);
	}

	@Override
	public List<TransactionDetails> PrintTransaction(int accountNo) throws BankAccountException {
		return bankDAO.PrintTransaction(accountNo);
	} 
		
}
