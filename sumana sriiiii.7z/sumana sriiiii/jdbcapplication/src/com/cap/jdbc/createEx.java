package com.cap.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class createEx {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// 5 steps +1
		//step-1 loading the driver class----->OracleDriver
		Class.forName("oracle.jdbc.driver.OracleDriver");//jdbc.jar
		//step-2 create the connection
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg405","training405");
		//step-3 create the statement
		Statement stmt=conn.createStatement();
		//step-4 execute query
		boolean val=stmt.execute("create table emp9(eid number,ename varchar2(20))");
		System.out.println("table created"+val);
		//ddl----->execute()--->boolean
		//dml----->executeUpdate----->Int
		//drl----->executeQuerry---->ResultSet
		///step-5 close the connection
		conn.close();
		
	}

}
