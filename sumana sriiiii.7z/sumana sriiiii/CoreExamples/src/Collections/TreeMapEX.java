package Collections;

import java.util.TreeMap;

public class TreeMapEX {
	public static void main(String[] args) {
		TreeMap<Integer, String> tr=new TreeMap<Integer, String>();//we can use only integer and strings
		//TreeMap tr=new TreeMap();//we can take any string and any integer
		tr.put(9, "sumana");
		tr.put(2, "vyshu");
		tr.put(8, "swathi");
		tr.put(6, "swapna");
		tr.put(3, "sai");
		System.out.println(tr);


}
}
