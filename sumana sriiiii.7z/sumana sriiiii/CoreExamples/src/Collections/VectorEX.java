package Collections;

import java.util.Vector;

public class VectorEX {
	public static void main(String[] args) {
		Vector v=new Vector();
		v.addElement("sumana");
		v.addElement(200);
		v.addElement("sai");
		v.addElement("is ");
		v.addElement("good");
		System.out.println(v);
		Vector v1=new Vector();
		v1.addElement("kittu");
		v1.addElement("sai");
		v1.addElement("kani");
		v1.addElement(0);
		//v1.removeAllElements();
		System.out.println(v.elementAt(0));
		
		
	}
}
