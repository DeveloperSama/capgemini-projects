package Collections;

import java.util.TreeSet;

public class TreeSetX {
	public static void main(String[] args) {
		TreeSet t=new TreeSet();
		t.add(100);//it will take only homogenius elements like numbers or characters
		t.add(123);//duplicates are not allowed
		t.add(234);
		t.add(876);
		t.add(100);
		System.out.println(t);
		TreeSet t1=new TreeSet();
		t.add(100);
		t.add(123);
		t.add(234);
		t.add(876);
		t.add(100);
	}

}
