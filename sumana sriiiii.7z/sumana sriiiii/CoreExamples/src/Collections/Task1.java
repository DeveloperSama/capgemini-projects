package Collections;

import java.util.ArrayList;
class Employee
{
	String name;
	int eid;
	Float sal;
	Employee(String name,int eid,Float sal){
		this.name=name;
		this.eid=eid;
		this.sal=sal;
		}
	
@Override
	public String toString() {
		return "Employee [name=" + name + ", eid=" + eid + ", sal=" + sal + "]";
	}
}
public  class Task1 {
	public static void main(String[] args) {
		
		Employee50 e1=new Employee50("sumana",12,10.7f);
		Employee50 e2=new Employee50("ravana",12,149.7f);
		Employee50 e3=new Employee50("bhavana",12,50.7f);
				ArrayList a1=new ArrayList();
				a1.add(e1);
				a1.add(e2);
				a1.add(e3);
				System.out.println(a1);
	}
	}



