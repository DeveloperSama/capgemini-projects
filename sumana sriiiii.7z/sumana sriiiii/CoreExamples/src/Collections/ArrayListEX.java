package Collections;

import java.util.ArrayList;

public class ArrayListEX {
	public static void main(String[] args) {
		ArrayList a1=new ArrayList();//default size 10
		//to increase automatically we use formula((cc*3/2)+1)
		// cc means current capacity (10*3/2)+1=15+1=16
a1.add(1);
a1.add('k');
a1.add("sumana");
a1.add(7673);
a1.add(9.3f);
a1.add(7673);//duplicates are allowed and insertion is preserverd
a1.add(1);
a1.add('k');
a1.add("sumana");
a1.add(7673);
a1.add(9.3f);
a1.add(7673);
a1.add(1);
a1.add('k');
a1.add("sumana");
a1.add(7673);
a1.add(9.3f);
a1.add(7673);
System.out.println(a1);

	}

}
