package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class EmpMap {
	public static void main(String[] args) {
		HashMap<String,Integer>hm=new HashMap<String,Integer>();
		hm.put("e101", 1500);
		hm.put("e102", 2000);
		hm.put("e103", 2500);
		hm.put("e104", 1500);
		hm.put("e105", 2000);
		//System.out.println(hm);
		Set s=hm.entrySet();
		
		Iterator itr=s.iterator();
		while(itr.hasNext())
		{
			//Entry entry=(Entry) itr.next();
			//System.out.print(entry.getKey());
		//System.out.print(entry.getValue());
		
			//System.out.println(entry);
			System.out.println(itr.next());
			
	}

}
}
