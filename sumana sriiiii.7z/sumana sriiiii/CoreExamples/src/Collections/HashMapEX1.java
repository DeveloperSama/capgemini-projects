package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapEX1 {
	public static void main(String[] args) {
		HashMap<Integer, String> hm=new HashMap<Integer, String>();//we can use only integer and strings
		//HashMap hm=new HashMap();//we can take nay string and any integer
		hm.put(1, "sumana");
		hm.put(2, "vyshu");
		hm.put(3, "swathi");
		hm.put(4, "swapna");
		hm.put(5, "sai");
		System.out.println(hm);
		//Set s=hm.keySet();//to show key values
	Set s=hm.entrySet();
	
		Iterator itr=s.iterator();
		while(itr.hasNext())
		{
			Entry entry=(Entry) itr.next();
			System.out.print(entry.getKey());
			System.out.print(entry.getValue());
			System.out.println();
			//System.out.println(itr.next());
			
		}

}
}
