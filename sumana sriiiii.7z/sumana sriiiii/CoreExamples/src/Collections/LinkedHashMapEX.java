package Collections;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class LinkedHashMapEX {
	//duplicates are not allowed and insertion order is preserved
		public static void main(String[] args) {
			LinkedHashMap<Integer, String> lh=new LinkedHashMap<Integer, String>();//we can use only integer and strings
			//LinkedHashMap lh=new LinkedHashMap();//we can take nay string and any integer
			lh.put(1, "sumana");
			lh.put(2, "vyshu");
			lh.put(3, "swathi");
			lh.put(4, "swapna");
			lh.put(5, "sai");
			System.out.println(lh);

}
}
