package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
class Employee50{
	String name;
	int eid;
	Float sal;
	Employee50(String name,int eid,Float sal){
		this.name=name;
		this.eid=eid;
		this.sal=sal;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", eid=" + eid + ", sal=" + sal + "]";
	}
	
}

public class Task2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//System.out.println("enter name");
		//System.out.println("enter mobile number");
		//String s1=sc.next();
	
		
		
	
	Employee50 e1=new Employee50("sumana",10,89.6f);
	Employee50 e2=new Employee50("vaishy",11,67.9f);
	Employee50 e3=new Employee50("kamal",12,55.3f);
	Employee50 e4=new Employee50("patel",13,86.5f);
	
	
		HashMap<String ,Employee50> hm=new HashMap<String, Employee50>();
		hm.put("977393043",e1);
		hm.put("764868497",e2);
		hm.put("746476744",e3);
		hm.put("764874561",e4);
		//Employee50 emp=hm.get(s1);
		//System.out.println(emp.sal);
		//System.out.println(hm.get(emp.sal));
		//System.out.println("your old sal:"+emp.sal);
		//System.out.println("your update sal:"+(emp.sal+1000));
	
				//System.out.println(hm);
				//Set s=hm.keySet();
		Set s=hm.entrySet();
				Iterator itr=s.iterator();
	
				while(itr.hasNext())
				{
					Entry entry=(Entry)itr.next();
					System.out.println(entry.getKey());
					System.out.println(entry.getValue());
				}
				//System.out.println("sumana");
	//System.out.println("977393043");
	}
	}
		
		
			


