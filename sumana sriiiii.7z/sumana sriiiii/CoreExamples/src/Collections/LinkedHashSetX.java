package Collections;

import java.util.LinkedHashSet;

public class LinkedHashSetX {
	public static void main(String[] args) {
	LinkedHashSet Lh=new LinkedHashSet();//duplicates are not allowed and insertion arder is preserved
	Lh.add(12);
	Lh.add(123);
	Lh.add("sai");
	Lh.add(1.30f);
	System.out.println(Lh);
	
}
}


