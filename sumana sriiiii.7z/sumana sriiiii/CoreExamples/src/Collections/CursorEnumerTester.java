package Collections;

import java.util.Enumeration;
import java.util.Vector;

public class CursorEnumerTester {
	public static void main(String[] args) {
		Vector dayNames=new Vector();
		dayNames.add("sunday");
		dayNames.add("monday");
		dayNames.add("tuesday");
		dayNames.add("wedday");
		dayNames.add("thursday");
		dayNames.add("friday");
		dayNames.add("satday");
		System.out.println(dayNames);
		Enumeration days=dayNames.elements();
		while(days.hasMoreElements())//hasnext();
		{
			System.out.println(days.nextElement());//next
		}
		
	}

}
