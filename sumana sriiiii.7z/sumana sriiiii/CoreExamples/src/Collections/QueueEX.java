package Collections;

import java.util.Iterator;
import java.util.PriorityQueue;

public class QueueEX {


		public static void main(String[] args) {
			PriorityQueue<String> lh=new PriorityQueue<String>();
			
			lh.add( "a");
			lh.add( "b");
			lh.add("c");
			lh.add("d");
			lh.add("e");
			//System.out.println(lh.element());
		//	System.out.println(lh.peek());
			//System.out.println("head:"+lh.poll());//null
			//System.out.println("head:"+lh.remove());//exception
			System.out.println(lh);		
System.out.println("iterating the queue elements");
Iterator itr=lh.iterator();
while(itr.hasNext()){
	System.out.println(itr.next());//to get in next line
}
}
}



