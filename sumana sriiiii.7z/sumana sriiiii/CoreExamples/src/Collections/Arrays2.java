package Collections;

public class Arrays2 {
		  
		    	public boolean sum28(int[] nums) {
		    		  


		        boolean b=false;
		        int sum=0;
		        for(int i=0;i<nums.length;i++){
		        if(nums[i]==2)
		        sum=sum+2;
		        }
		        if(sum==8)
		        b=true;
		        return b;
		      }
		    }

		      