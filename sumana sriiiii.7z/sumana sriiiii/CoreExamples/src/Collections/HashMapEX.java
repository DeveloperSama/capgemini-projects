package Collections;

import java.util.HashMap;

public class HashMapEX {//duplicates is not allowedand insertion order is not  preserved
public static void main(String[] args) {
	HashMap<Integer, String> hm=new HashMap<Integer, String>();//we can use only integer and strings
	//HashMap hm=new HashMap();//we can take nay string and any integer
	hm.put(1, "sumana");
	hm.put(2, "vyshu");
	hm.put(3, "swathi");
	hm.put(4, "swapna");
	hm.put(5, "sai");
	//System.out.println(hm);
	HashMap hm1=new HashMap();
	hm1.put(7, "puppu");
	hm1.put(81, "kittu");
	hm1.put("sai", 5);
	//hm.putAll(hm);
	//hm1.putAll(hm);
	//hm.get(4);
	//System.out.println(hm.get(4));
	//hm.remove(3);
	//System.out.println(hm);
	
	//System.out.println(hm.containsKey(4));
	System.out.println(hm1.containsValue(5));
	
}
}
