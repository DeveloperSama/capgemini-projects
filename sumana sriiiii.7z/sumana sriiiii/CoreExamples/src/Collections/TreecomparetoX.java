package Collections;

public class TreecomparetoX {
	/*public static void main(String[] args) {
		
		System.out.println("summu".compareTo("vyshu"));
		System.out.println("A".compareTo("Z"));
		System.out.println("Z".compareTo("A"));
		System.out.println("A".compareTo("A"));

}
}
*/
	public static void main(String[] args) {
		Integer a=20;
		Integer b=81;
		System.out.println(a.compareTo(b));
	}
}