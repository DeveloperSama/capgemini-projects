package Collections;


import java.util.ArrayList;
import java.util.LinkedList;

public class LinkedListEX {
	public static void main(String[] args) {
		LinkedList a1=new LinkedList();//default size 10
		//to increase automatically we use formula((cc*3/2)+1)
		// cc means current capacity (10*3/2)+1=15+1=16
		a1.add(1);
		a1.add('k');
		a1.add("sumana");
		a1.add(7673);
		a1.add(9.3f);
		a1.add(767);
		a1.add(77);
		//System.out.println(a1);
		LinkedList al1=new LinkedList();
		al1.add("vaishu");
		al1.add("and");
		al1.add("sumana");
		al1.add("best friends");
		al1.add("from");
		al1.add(13);
		al1.add("standard");
//al1.addFirst(a1);
//a1.addFirst(al1);
//a1.addLast(al1);
//al1.addLast(a1);
//al1.getFirst();
		//a1.getFirst();
		//al1.getLast();
		//a1.getLast();
//System.out.println(al1.removeFirst());
//a1.addAll(al1);
//al1.push(a1);
//a1.remove(al1);
		System.out.println(a1.removeLast());
//System.out.println(al1);
//System.out.println(a1.getLast());
System.out.println(a1);


	}

}
