package Collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class HashSetEX {//hashset is used for 
public static void main(String[] args) {
	HashSet hs=new HashSet();
	hs.add(12);
	hs.add(123);
	hs.add("sai");
	hs.add(1.30f);
	hs.add(1.30f);//in hashset  duplicate are not allowed and insertion order is preserved
	System.out.println(hs);
	
}
}
