package Collections;

import java.util.TreeSet;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class TreeCompareTo2 {
	public static void main(String[] args) {
		TreeSet t=new TreeSet(new MyComparator());
		t.add("sumana");
		t.add("kaiai");
		t.add("vyshu");
		t.add("harsha");
		System.out.println(t);

}
}
class MyComparator implements Comparator{
	
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		//Integer i1=(Integer) o1;
	//	Integer i2=(Integer) o2;
		//return+ve=>obj1 has to come before obj2
		//return -ve=>obj1 has to come after obj2
		//return 0 if both objects are same
		String s1=(String) o1;
		String s2=o2.toString();
		//return -i1.compareTo(i2);
		return s2.compareTo(s1);
		/*return i2.compareTo(i1);
		 * if(i1<i2)//13<10...->
		 * return +1;
		 * else if(i1>i2)
return -1;
return 0;
	}*/
}
}
