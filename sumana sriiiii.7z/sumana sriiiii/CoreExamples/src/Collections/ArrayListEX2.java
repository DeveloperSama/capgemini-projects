package Collections;

import java.util.ArrayList;

public class ArrayListEX2 {
	public static void main(String[] args) {
		ArrayList a1=new ArrayList();//default size 10
		//to increase automatically we use formula((cc*3/2)+1)
		// cc means current capacity (10*3/2)+1=15+1=16
a1.add(1);
a1.add('k');
a1.add("sumana");
a1.add(7673);
a1.add(9.3f);
a1.add(767);
a1.add(77);//duplicates are allowed and insertion is preserverd
System.out.println(a1);
ArrayList al1=new ArrayList();
al1.add("vaishu");
al1.add("and");
al1.add("sumana");
al1.add("best friends");
al1.add("from");
al1.add(13);
al1.add("standard");
//al1.addAll(a1);
//al1.remove(a1);
a1.addAll(al1);
//a1.remove(al1);
//System.out.println(a1);
//al1.retainAll(a1);
//a1.retainAll(al1);
//System.out.println(al1.contains("sumana"));
//System.out.println(al1.contains("there"));
//al1.indexOf(2);
//System.out.println(al1.indexOf("sumana"));
//System.out.println(a1.indexOf(7673));
//System.out.println(al1);
//System.out.println(al1.isEmpty());
//al1.clear();
//al1.trimToSize();

System.out.println(al1);
//System.out.println(a1.size());
//ArrayList<String> a11=new ArrayList<String>();
//a11.add("hiii");
//a11.add("vyshu");
//a11.add("sumana");
//Object a[]=a11.toArray();
//System.out.println(a11);


	}

}
