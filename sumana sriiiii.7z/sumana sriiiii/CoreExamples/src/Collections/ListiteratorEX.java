package Collections;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListiteratorEX {
	public static void main(String[] args) {
		ArrayList  a1=new ArrayList();
		a1.add("vyshu");
		a1.add("summu");
		a1.add(123);
		a1.add(1);
		System.out.println(a1);
		
		ListIterator litr=a1.listIterator();
		while(litr.hasNext())//in forward direction
		{
			System.out.println(litr.next()+"");
		}
		while(litr.hasPrevious())//in backword direction
		{
			String val=(String)litr.previous();
			if(val.equals(123)){
				litr.set("capgemini");//vyshu,summu,123,1.9f....>capgemini
				System.out.println(litr.next());
				litr.previous();
			}else
			{
				System.out.println(val);
			}
		
		}
	}

}
