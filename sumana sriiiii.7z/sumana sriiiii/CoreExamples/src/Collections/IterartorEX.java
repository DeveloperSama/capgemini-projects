package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class IterartorEX {
	public static void main(String[] args) {
		ArrayList a1=new ArrayList();
		
a1.add("sunil");
a1.add("sandeep");
a1.add("sumana");
a1.add("suresh");
a1.add("sandeep");
a1.add("kiran");
a1.add("kiran"); 
System.out.println(a1);
Iterator itr1=a1.iterator();
while(itr1.hasNext())
{
	String name=(String)itr1.next();//sunil
	if(name.equals("sandeep"))
	{
		itr1.remove();
	}else{
//System.out.println(itr1.next());	
		System.out.println(name);
}
	}
}
}