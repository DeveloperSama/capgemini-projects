package Collections;

import java.util.Stack;

public class StackEX {
public static void main(String[] args) {
	Stack sc=new Stack();//stack means last in first out
	sc.push("sumana");
	sc.push("vyshu");//to add an object
	sc.pop();//to remove up and return up top sumana,sumana1
	sc.push("sumana1");
	sc.peek();//to return top of the stack
	sc.push(1.0f);
	//sc.empty();//checks obj is empty or not
	//sc.search("sumana");//to check obj is avaliasble or not
	//System.out.println(sc.search("sumana"));
	System.out.println(sc.empty());
	//System.out.println(sc);
	
	
}
}
