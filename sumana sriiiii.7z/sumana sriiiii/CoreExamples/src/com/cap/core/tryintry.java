package com.cap.core;

public class tryintry {
	public static void main(String[] args) {
		try {
			int a[] = {1,3,30/4,5,6};// 0,1,2,3,4
			a[4] = 30 / 4;
			String s = "123";
			int x = Integer.parseInt(s);// converting string into integer
			System.out.println(s.length());
			System.out.println("no error" + a[4] + "" + x);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("please enter valid index");
		} catch (ArithmeticException e) {
			System.out.println("dont enter zero as denominator");
		} catch (NumberFormatException e) {
			System.out.println("we can't convert string to number " + e);
		} catch (Exception e) {
			System.out.println("unable to find length of the string" + e);// e.printStackTrace();
			// System.out.println(e.getmessage());
		} finally {
			System.out.println("executes every time for closing connection");

		}
		System.out.println("remaining code executed...");
	}
}


