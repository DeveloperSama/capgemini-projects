package com.file.examples;
/*import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.serialization;


public class serialization {
	private String sname;
		private int sid;
		private float sgpa;
		public String getSname() {
			return sname;
		}
		public void setSname(String sname) {
			this.sname = sname;
		}
		public int getSid() {
			return sid;
		}
		public void setSid(int sid) {
			this.sid = sid;
		}
		public float getSgpa() {
			return sgpa;
		}
		public void setSgpa(float sgpa) {
			this.sgpa = sgpa;
		}
		
	}
public class Serialization{
	public static void main(String args[])throws IOException{
		ObjectStream s=new ObjectStream();
		s.setSname("summu");
		s.setSid(12335);
		s.setSgpa(9.8f);
		FileOutputStream fos=new FileOutputStream("capgemini2.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.write
		
		
	}
}
}
*/