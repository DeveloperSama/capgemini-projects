package com.file.examples;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedStream {
	public static void main(String[] args) throws IOException {
		String s="sumana.txt";
		FileOutputStream fos=new FileOutputStream(s);
		BufferedOutputStream bos=new BufferedOutputStream(fos);
		String s1="sai saketh";
		byte b[]=s1.getBytes();//converting string s1 into
	
		bos.write(b);
		bos.write(97);
		bos.flush();
		FileInputStream fis=new FileInputStream(s);
		BufferedInputStream bis=new BufferedInputStream(fis);
		int i=bis.read();
		while(i!=-1)
		{
			System.out.println((char)i);
			i=bis.read();
		}
		
		
	}

}
