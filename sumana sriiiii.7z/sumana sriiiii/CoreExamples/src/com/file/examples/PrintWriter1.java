package com.file.examples;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;

public class PrintWriter1 {
public static void main(String[] args) throws IOException{
	FileWriter fw=new FileWriter("abhi.txt");
	PrintWriter out=new PrintWriter(fw);
	out.println(1000);
	out.println(false);
	out.println('s');
	out.println("capgemini");
	out.flush();
	out.close();
	
}


}

