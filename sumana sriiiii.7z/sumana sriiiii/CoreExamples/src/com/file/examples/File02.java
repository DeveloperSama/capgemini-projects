package com.file.examples;

import java.io.File;
import java.io.IOException;

class File02{
	public static void main(String[] args) throws IOException{
		File f=new File("my folder1/my folder2/ myfile.txt");
		f.getParentFile().mkdir();
		f.createNewFile();
		f.delete();
		System.out.println(f.delete());
		System.out.println("done"+f.getParent());
	}
}

