package com.file.examples;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferWriter {
	public static void main(String[] args) throws IOException{
		FileWriter fw=new FileWriter("abc.txt");
		BufferedWriter bw= new BufferedWriter(fw);
		bw.write(97);//character
		bw.write("vyshu is intelegent");
		bw.write("\n");
		char [] ch1={'a','b','c','d'};
		bw.write(ch1);
		bw.write("\n");
		bw.flush();//optional used to insert all the value if any value is missed
		bw.close();		//close the connection
		
		
		
	
	}

}
