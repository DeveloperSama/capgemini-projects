package com.file.examples;


import java.io.FileReader;
import java.io.IOException;

public class FileReader1 {
	private static FileReader fr1;

	public static void main(String[] args) throws IOException {
		fr1 = new FileReader("abc.txt");
		int i=fr1.read();//size 3 abc
		while(i!=-1)//eof the file==>-1
		{
			System.out.println((char)i);
			i=fr1.read();
			
			
			
		}
	}

}
