package com.file.examples;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Bufferinout {
public static void main(String[] args) throws IOException{
	String filepath="sai1.txt";
	//1.create stream object
	FileOutputStream fos=new FileOutputStream(filepath);//2 bytes
	//2.pass stream object to buffer stream constructor
	BufferedOutputStream bos=new BufferedOutputStream(fos);//1024 bytes
	String s="oracle.com";
	byte[] b=s.getBytes();
	bos.write(b);
	bos.flush();
	//1.create stream object
	FileInputStream fis=new FileInputStream(filepath);
	//2.pass stream object tobufferstream constructer
	BufferedInputStream bis=new BufferedInputStream(fis);
	int i;
	while((i=bis.read())!=-1) {
		System.out.println((char) i);
	}
}
}
