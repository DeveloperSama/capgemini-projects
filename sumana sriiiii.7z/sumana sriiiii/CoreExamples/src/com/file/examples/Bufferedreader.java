package com.file.examples;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Bufferedreader {
	public static void main(String[] args) throws IOException{
		
	
	FileReader fr1=new FileReader("abc.txt");
	

	BufferedReader br1=new BufferedReader(fr1);
	String line=br1.readLine();//size 3 abc
	while(line!=null)//eof the file==>-1
	{
		System.out.println((line));
		line=br1.readLine();
	}
	}
}
		

