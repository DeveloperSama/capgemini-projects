package com.file.examples;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileExample11 {
public static void main(String[] args) throws IOException {
	FileWriter  fw=new FileWriter("gmail.txt");
	PrintWriter out=new PrintWriter(fw);
	out.println("capgemini");
	out.print("capgemini");
}
}
