package com.file.examples;

import java.io.FileWriter;
import java.io.IOException;

public class FilewriterEx {
public static void main(String[] args) throws IOException{
	FileWriter fw=new FileWriter("sumana.txt");//it will create
	fw.write(100);//character of askey value
	fw.write("vyshu is intelegent");
	fw.write("\n");
	char [] ch1={'a','b','c','d'};
	fw.write(ch1);
	fw.write("\n");
	fw.flush();
	fw.close();
}
}
