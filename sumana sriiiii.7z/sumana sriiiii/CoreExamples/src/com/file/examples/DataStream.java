package com.file.examples;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataStream {
	public static void main(String[] args) throws IOException {
		FileOutputStream fos=new FileOutputStream("hello.txt");
			DataOutputStream dos=new DataOutputStream(fos);
			dos.writeInt(10);
			dos.writeUTF("VINITHA");
			FileInputStream fis=new FileInputStream("hello.txt");
			DataInputStream dis=new DataInputStream(fis);
			System.out.println("Int :"+dis.readInt());
			System.out.println("String :"+dis.readUTF());
	}

}
