package com.file.examples;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileExample12 {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your name");
		String uname=sc.next();
		System.out.println("enter your password");
		String password=sc.next(); 
		FileReader fr=new FileReader("gmail.txt");
		BufferedReader br=new BufferedReader(fr);
		String uname1=br.readLine();
		String password1=br.readLine();
		if(uname.equals(uname1)&&password.equals(password1))
			System.out.println("login success");
		else
			System.out.println("please enter valid credentials");
	}

}
