package com.file.examples;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStream {
	public static void main(String[] args) throws IOException {
		String s="tmp.txt";
		//byte stream
		FileOutputStream fos=new FileOutputStream(s);
		//for(int i=0; i<10; i++){
		fos.write(97);
		
		FileInputStream fis=new FileInputStream(s);
		int i=fis.read();
		while(i!=-1){
			System.out.println(i);
			i=fis.read();

		}
		
	}

}
