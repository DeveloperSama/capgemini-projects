package com.file.examples;
import java.io.File;
import java.io.IOException;

public class FileEx {
	public static void main(String args[]) throws IOException{
	File f=new File("cap.txt");
	f.createNewFile();
	System.out.println("created");

}
}