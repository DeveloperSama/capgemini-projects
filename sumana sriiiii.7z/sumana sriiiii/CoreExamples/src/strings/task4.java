package strings;

public class task4 {
		    public static void main(String[] args) {
	        String s1="sumana sri";
	        String s2="sama sri";
	        System.out.println(s1.endsWith(s2));
	    }

	 

	}
