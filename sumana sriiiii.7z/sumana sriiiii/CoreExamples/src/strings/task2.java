package strings;


	import java.util.Scanner;

	public class task2 {
	
		public static void main(String[] args) 
		{
			String a="java standard edition";
			String s1= a.substring(0,1).toUpperCase()+a.substring(1).toLowerCase();
			System.out.println(s1);
		}
	}


