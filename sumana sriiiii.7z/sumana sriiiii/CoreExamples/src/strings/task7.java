package strings;

public class task7 {
	
		public static void main(String[] args) 
		{
			String a="bvrit college";
			String s1= a.substring(0,3).toLowerCase()+a.substring(3,4).toUpperCase()+a.substring(4).toLowerCase();
			System.out.println(s1);
		}
	}


