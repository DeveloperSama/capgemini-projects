package Multithread;
class Account{
	public int balance;//5000
	public  Account(){
	balance=5000;
	}
	public synchronized void withdraw(int bal){
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	balance=balance-bal;
	System.out.println("Amount withdraw="+bal);
	System.out.println("Remaining balance="+balance);		
	}

public synchronized void deposited(int bal){
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
balance=balance+bal;
System.out.println("Amount withdraw="+bal);
System.out.println("Remaining balance="+balance);	
}
public synchronized void enquiry(){
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
System.out.println("Remaining balance="+balance);	
}
}
 class Trans2 implements Runnable {
	 Account obj; //has-a
	 Trans2 (Account a){
		 obj=a;
	 }
	 public void run(){
		 obj.withdraw(500);
		 obj.deposited(1000);
		 obj.enquiry();
	 }
 }
public class BankSynchronizedEX {
	public static void main(String[] args) {
		Account a=new Account();
		Trans2 w1=new Trans2(a);
		Thread t1=new Thread(w1);
		Thread t2=new Thread(w1);
		t1.start();
		t2.start();

	}
}


