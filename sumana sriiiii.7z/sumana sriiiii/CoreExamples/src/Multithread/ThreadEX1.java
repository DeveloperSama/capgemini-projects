package Multithread;
class Test implements Runnable{

	@Override
	public void run() {
		for(int i=0;i<3;i++)
		{
			
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			
			
			System.out.println("child thread");
		}
	}

	
}
class sumana implements Runnable{

	@Override
	public void run() {
	for(int i=0;i<12;i++)
	{
		System.out.println("new thread");
	}
	}
	
}

public class ThreadEX1 {
	public static void main(String[] args) {
		Test t=new Test();
		sumana s1=new sumana();
	Thread t2=new Thread(s1);
		Thread t1=new Thread(t);
				t1.start();
				t2.start();
		for(int i=1;i<9;i++)
		{
			System.out.println("parent thread");
		}
	}

}
