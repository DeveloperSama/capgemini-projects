package Multithread;
class sumana3 extends Thread
{
	public void run(){
		
		for(int i=1;i<5;i++){
			//Thread.currentThread().setName("prasad");
			Thread.currentThread().setPriority(10);
			//Thread.currentThread().getName();//to get only name
			//Thread.currentThread().getPriority();
			System.out.println("kittu");
			
		///*System.out.println(Thread.currentThread().setPriority());
			//System.out.println(Thread.currentThread().getPriority());
			//System.out.println(Thread.currentThread().getPriority());//this is used for only priority to print
			
			
	//System.out.println(Thread.currentThread().getName());
			//System.out.println(Thread.currentThread());
			
		}
		
	}

}
public class ThreadEX2 {
	public static void main(String[] args) {
		sumana3 s3=new sumana3();
				s3.start();
				/*for(int i=1;i<5;i++){
					System.out.println("saiiiii");*/
					System.out.println(Thread.currentThread());
				}
	}


