package Multithread;


	class Test100 implements Runnable{

		@Override
		public void run() {
			for(int i=0;i<3;i++)
			{
				
				/*try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
				
				
				System.out.println("child thread");
			}
		}

		

		
	}
	/*class sumana implements Runnable{

		@Override
		public void run() {
		for(int i=0;i<12;i++)
		{
			System.out.println("new thread");
		}
		}
		
	}*/

	public class JoinEX { 
		public static void main(String[] args) throws InterruptedException {
			Test100 t=new Test100();
		Thread t2=new Thread(t);
			t2.start();
			t2.join();
			
				
			for(int i=1;i<9;i++)
			{
				System.out.println("parent thread");
			}
		}

	}



