package Multithread;

public class InterThreadCommunicationEX {

}
