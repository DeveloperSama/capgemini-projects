package Multithread;
class Frist {
public synchronized void display(String msg)//welcome,new//
{
	
	
		System.out.println("["+msg);//welcome
		
		
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("]");
		
		
	}
}
class Second extends Thread{
	String msg;//welcome,new
	Frist fobj;//has-a
	Second(Frist fobj,String msg){
		this.fobj=fobj;
		this.msg=msg;
		this.start();
	}
	public void run(){
	fobj.display(msg);//welcome,new
}
}
public class SynchronizedEX {
public static void main(String[] args) {
	Frist fnew=new Frist();
	Second ss=new Second(fnew,"welcome");
	Second ss1=new Second(fnew,"new");
	Second ss2=new Second(fnew,"java programing");
	
}
}
