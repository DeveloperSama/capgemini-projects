package lamdaExpressionStream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class LamdaWithCollectionsAndStreams {
	public static void main(String[] args) {
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(10);
		al.add(20);
		al.add(13);
		al.add(60);
		al.add(15);
		System.out.println(al);
		List<Integer> l=al.stream().filter(i->i%2==0).collect(Collectors.toList());//filter parameter is predicate
		
		System.out.println("filter to print even value"+l);
		System.out.println("mapm to print doubl;e value");
		List<Integer> l1=al.stream().map(i->i*2).collect(Collectors.toList());
		System.out.println("map to print double value"+l1);
		long cn=al.stream().count();
		System.out.println("it will count no of elements" +al);
		List<Integer> l2=al.stream().sorted((i1,i2)->(i1<i2)? 1:((i1>i2)?-1:0)).collect(Collectors.toList());
		System.out.println("display in decending order"+l2);
		Integer minVal=al.stream().min((i1,i2)->-i1.compareTo(i2)).get();
		System.out.println("minimum value iss"+minVal);
		Integer maxVal=al.stream().max((i1,i2)->i2.compareTo(i1)).get();
		
		System.out.println("maximum value iss"+maxVal);
		//for each
		
	}

}
