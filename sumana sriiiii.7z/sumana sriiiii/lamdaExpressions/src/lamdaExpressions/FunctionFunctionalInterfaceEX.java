package lamdaExpressions;

import java.util.Date;
import java.util.function.Function;
import java.util.function.Supplier;

public class FunctionFunctionalInterfaceEX {
	public static void main(String[] args) {
		/*Function<Integer,Integer>f=i->2*i;//i=2
		Function<Integer,Integer>f1=i->i*i*i;
		System.out.println(f.apply(3));
		System.out.println(f.andThen(f1).apply(2));
		System.out.println(f.compose(f1).apply(2));*/
		/*Supplier<Date> sup=()->new Date();
		System.out.println(sup.get());*/
		
	}

}
