package lamdaExpressions;

import java.util.Scanner;

interface String1{
	public int stringLength(String name);
}

public class Length {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter student name");
		String name1=s.next();
		String1 L=name->name.length();
		System.out.println(L.stringLength(name1));
	}

}
