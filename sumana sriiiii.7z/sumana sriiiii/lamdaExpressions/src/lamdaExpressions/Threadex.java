package lamdaExpressions;
class sumana implements Runnable{

	@Override
	public void run() {
	for(int i=0;i<12;i++)
	{
		System.out.println("new thread");
	}
	}
}
public class Threadex  {
	public static void main(String[] args) {
		sumana s1=new sumana();
		Thread t=new Thread(s1);
		t.start();
		for(int i=1;i<9;i++)
		{
			System.out.println("parent thread");
		}
	}
}


