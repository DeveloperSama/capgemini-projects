package lamdaExpressions;

import java.util.Scanner;

/*interface Favourite{
	public void color();
}
public class Basic {
	public static void main(String[] args) {
		Favourite f=()->System.out.println("my favourite colour is:yellow");
		f.color();
	}
	

}*/


interface Addition{
	public int add(int a,int b);		
}
public class Basic{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first number");
		int X=sc.nextInt();
		System.out.println("enter second number");
		int Y=sc.nextInt();
	Addition c=(a,b)->a+b;
	System.out.println(c.add(X, Y));
}
}