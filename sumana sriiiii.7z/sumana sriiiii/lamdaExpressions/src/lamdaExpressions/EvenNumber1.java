package lamdaExpressions;

import java.util.function.Predicate;

/*public class EvenNumber1 {
	public static void main(String[] args) {
		
	
	
	int a[]={2,3,4,6,7,8,9};
	{
	for(int i=0;i<a.length;i++){
		if(a[i]%2==0)
			System.out.println("print even num:"+a[i]);	
	}
	
	}
	}
}*/
/**public class EvenNumber1{
	public static void main(String[] args) {
		int[] values={1,20,2,10,34,23,45,33};
		Predicate<Integer>pre=i->i%2==0;//intpredicate
		for(int val:values){
			if(pre.test(val)){
				System.out.println(val);
			}
		}
	}
}**/
public class EvenNumber1{
	public static void main(String[] args) {
		String []  values={"sumana","sai","puppy","vyashu"};
		Predicate<String> pre=s->s.length()%2==0;//>5
		for(String s1:values)
		
			if(pre.test(s1))
				System.out.println(s1);
	}
	
}
