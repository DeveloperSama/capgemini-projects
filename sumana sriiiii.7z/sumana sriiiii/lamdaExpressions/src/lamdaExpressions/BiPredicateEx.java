package lamdaExpressions;

import java.util.function.BiPredicate;
import java.util.function.BooleanSupplier;

public class BiPredicateEx {
	public static void main(String[] args) {
		BiPredicate<Integer, Integer> bi = (x, y) -> x > y;
		System.out.println(bi.test(5, 3));

       BooleanSupplier bs = () -> true; 
        System.out.println(bs.getAsBoolean());
	}

}
