/*package lamdaExpressions;

import java.util.function.IntToDoubleFunction;

public class ToIntFunction {
public static void main(String[] args) {
	ToIntFunction funcn1=i->i*i;
    ToIntFunction funcn2=i->i*i*i;
    
}
}
*/