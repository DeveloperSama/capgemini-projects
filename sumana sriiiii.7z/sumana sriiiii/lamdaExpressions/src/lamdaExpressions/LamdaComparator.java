package lamdaExpressions;

import java.util.Comparator;
import java.util.TreeMap;

public class LamdaComparator {
	public static void main(String[] args) {
		Comparator<Integer> c=(key,value)->{return -key.compareTo(value);};
				
				TreeMap<Integer,String> t=new TreeMap<Integer,String>(c);
		t.put(33,"akash");
		t.put(34,"sumana");
		t.put(65,"jai");
		t.put(98,"jai sai ram");
		System.out.println(t);
	
				
		
	}

}
