package lamdaExpressions;

public class SupplierEX2 {
	

}
