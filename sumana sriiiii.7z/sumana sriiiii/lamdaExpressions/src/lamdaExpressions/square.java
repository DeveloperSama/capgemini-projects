package lamdaExpressions;
interface square1{
	public int stringLength(String name);
}

public class square {
	public static void main(String[] args) {
		
	}

}
