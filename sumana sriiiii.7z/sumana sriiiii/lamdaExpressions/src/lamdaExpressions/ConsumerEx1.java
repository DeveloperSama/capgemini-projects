package lamdaExpressions;

import java.util.function.Consumer;

public class ConsumerEx1 {
	public static void main(String[] args) {
		//parameter can be anything and return void
		//Consumer<Integer> con=i->System.out.println(i);
		//con.accept(123);
		//con.accept(12);
		Consumer<String> con=i->System.out.println(i+  " ");
		con.accept("wellcome");
		con.accept("welcome to capgemini");
		
		
		
		
	}
	

}
