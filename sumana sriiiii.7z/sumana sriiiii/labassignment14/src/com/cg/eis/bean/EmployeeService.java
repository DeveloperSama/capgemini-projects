package com.cg.eis.bean;

public interface EmployeeService {

	void getEmployeeDetails(int eid, String ename, int sal);

}
