package cap.com12;

public class testQ {
public int a=30,b=6;
}
