
package cap.com20;
import cap.com12.testQ;


public class testZ extends testQ{
int c=6;
int d=a+b+c;
public static void main(String args[]) 
{
	testQ q=new testQ();
testZ z=new testZ();
System.out.println("private number"+z.d);
}
}