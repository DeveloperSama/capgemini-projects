package ConcurrentClass;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListEX1 {
public static void main(String[] args) {
    ArrayList<String> a1= new ArrayList<String>();
    a1.add("X");
    a1.add("Y");
    System.out.println(a1);
    CopyOnWriteArrayList<String> cowal=new CopyOnWriteArrayList<String>();
    cowal.addIfAbsent("A");
    cowal.add("B");
    cowal.addIfAbsent("B");
    System.out.println(cowal);
    cowal.addAllAbsent(a1);
    System.out.println(cowal);
    ArrayList<String> al1=new ArrayList<String>();
    al1.add("X");
    al1.add("Y");
    al1.add("Z");
    System.out.println(al1);
    cowal.addAllAbsent(al1);
    System.out.println(cowal);
}
}

