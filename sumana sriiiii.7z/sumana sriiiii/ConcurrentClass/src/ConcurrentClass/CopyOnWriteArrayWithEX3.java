package ConcurrentClass;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayWithEX3 extends Thread{
	    static CopyOnWriteArrayList<String> al=new CopyOnWriteArrayList<String>();
	    public void run(){
	    try {
	        Thread.sleep(2000);
	    } catch (InterruptedException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }
	    System.out.println("We are in child method");
	    al.add("C");
	    
	    }
	    
	public static void main(String[] args) throws InterruptedException {
	    al.add("A");
	    al.add("B");
	    CopyOnWriteArrayWithEX3 ca=new CopyOnWriteArrayWithEX3();
	    ca.start();
	    Iterator<String> itr=al.iterator();
	    while(itr.hasNext()){
	        String values=(String )itr.next();
	        System.out.println("Main thread"+values);
	        Thread.sleep(2000);
	        
	    }System.out.println(al);
	}
	}
	 

