package ConcurrentClass;




import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

 

public class ConcurrentClassEX extends Thread {

 

    static ConcurrentHashMap<Integer, String> hash = new ConcurrentHashMap<Integer, String>();

 

    public void run() {
        System.out.println("child thread got chance");
        hash.put(40, "welcome to IBM");
    }

 

    public static void main(String[] args) throws InterruptedException {
        hash.put(10, "Suresh");
        hash.put(20, "hello");
        hash.put(30, "hai");
        ConcurrentClassEX t = new ConcurrentClassEX();
        t.start();
        Set<Integer> s = hash.keySet();
        Iterator<Integer> itr = s.iterator();
        while (itr.hasNext()) {
            Object i = itr.next();
            int i1 = (int) i;
            System.out.println("main thread iterated");
            System.out.println("current class" + i);
        }
    }
}