package ConcurrentClass;
	import java.util.concurrent.ConcurrentHashMap;
	public class ConcurrentHashMapEx1 {
	public static void main(String[] args) {
	    ConcurrentHashMap<Integer, String> cm=new ConcurrentHashMap<Integer, String>();
	    cm.put(10, "Suresh");
	    cm.put(20, "Naresh");
	    cm.put(30, "Harish");
	    System.out.println(cm);
	    
	    cm.putIfAbsent(20, "ramesh");
	    System.out.println(cm);
	    cm.remove(30, "Somesh");
	    cm.replace(20, "Naresh");
	    
	    
	}
	}