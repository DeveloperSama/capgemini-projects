package ThreadPolls;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ThreadPoolEX2 {
	public static void main(String[] args) {
		ScheduledExecutorService service=Executors.newScheduledThreadPool(10);//task to run after 10 sec delay
		service.schedule(new task3(),10,TimeUnit.SECONDS);//10 is initial delay 
		//task to run repeatedly for every 10 sec
		//service.scheduleAtFixedRate(new task3(), 15, 10,TimeUnit.SECONDS);
		//task to run repeatedly fo every 10 sec
		//after [previous tasks complete
		service.scheduleWithFixedDelay(new task3(),15,10, TimeUnit.SECONDS);
	}}
class task3 implements Runnable
{
	public void run()
	{
		Date date=new Date();
		System.out.println(Thread.currentThread().getName()+""+new SimpleDateFormat("HH:mm:ss").format(date));
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		
	}

}
