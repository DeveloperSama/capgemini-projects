package cap.com;

 class privatemethod {
	 private void m1(){
		 System.out.println("hii");
	 }
	 int a=1,b=8;
	 int c=a+b;
	 public static void main(String args[]){
		 privatemethod b=new privatemethod();
		 b.m1();
		 System.out.println(b.c);
	 }
	 

}
