package cap.com;

class A
{
public  void m1()
{
System.out.println("public method");	
}
}
public class test{
	public int eid=123;
	public static void main(String args[])
	{
		A a=new A();
		a.m1();
		test T=new test();
	System.out.println(T.eid);
	}
}