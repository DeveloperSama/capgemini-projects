package com.cap.dao;

import java.util.HashMap;
import java.util.Map;

import com.cap.bean.Employee;

public class EmployeeDaoImp1 implements EmployeeDao {
Map<Integer,Employee> employees=new HashMap<Integer,Employee>();
	public void insertEmployee(Employee employee) {
		employees.put(employee.getEmpId(),employee);
		// TODO Auto-generated method stub
		
	}

	public Employee retriveEmployee(Integer eid) {
		Employee emp=employees.get(eid);
		// TODO Auto-generated method stub
		return emp;
	}

}
