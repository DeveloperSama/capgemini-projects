package com.cap.service;

import com.cap.bean.Employee;
import com.cap.dao.EmployeeDao;
import com.cap.dao.EmployeeDaoImp1;

public class EmployeeServiceImp1 implements EmployeeService {
EmployeeDao dao=new EmployeeDaoImp1();
	
	public void insertEmployee(Employee employee) {
		dao.insertEmployee(employee);
		
	}

	
	public Employee retriveEmployee(Integer eid) {
		Employee emp=dao.retriveEmployee(eid);
		
		return emp;
	}

}
