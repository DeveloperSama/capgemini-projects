package com.cap.service;

import com.cap.bean.Employee;

public interface EmployeeService {
	void insertEmployee(Employee employee);
	Employee retriveEmployee(Integer eid);
	

}
