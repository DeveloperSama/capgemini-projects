/*package com.cap.ui;

import java.util.Scanner;

import com.cap.bean.Employee;
import com.cap.service.EmployeeService;
import com.cap.service.EmployeeServiceImp1;

public class Mainui {
	public static void main(String[] args) { 
		EmployeeService service=new EmployeeServiceImp1();
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter your id:");
		int empId=scanner.nextInt();
		System.out.println("enter your name:");
		String empName=scanner.next();
		System.out.println("enter your salary:");
		int empSal=scanner.nextInt();
		

		Employee employee=new Employee();
		employee.setEmpId(empId);
		employee.setEmpName(empName);
		employee.setEmpSal(empSal);
		System.out.println("inserting employee is map*********");
		service.insertEmployee(employee);
		System.out.println("employee inserted");
		System.out.println("fetching employee");
		
		service.insertEmployee(employee);
		System.out.println("***********************");
		System.out.println("Employee Inserted");
		System.out.println("****************************");
		System.out.println("fetching employee");
		//calling service method to fetch employee info
		Employee emp=service.retriveEmployee(empId);
		
		System.out.println(emp);
		scanner.close();
	}

}*/
package com.cap.ui;

import java.util.Scanner;

import com.cap.bean.Employee;
import com.cap.service.EmployeeService;
import com.cap.service.EmployeeServiceImp1;

public class Mainui {
	static EmployeeService service=new EmployeeServiceImp1();
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) { 
		while(true)
		{
			System.out.println("welcome to employe Application");
		System.out.println("1.create employee");
		System.out.println("2.select employee");
		
		System.out.println("3.exit");
		
		int option=scanner.nextInt();
		switch(option)
		{
		case 1:
			System.out.println("enter your id:");
		int empId=scanner.nextInt();
		System.out.println("enter your name:");
		String empName=scanner.next();
		System.out.println("enter your salary:");
		int empSal=scanner.nextInt();
		

		Employee employee=new Employee();
		employee.setEmpId(empId);
		employee.setEmpName(empName);
		employee.setEmpSal(empSal);
		System.out.println("inserting employee is map*********");
		service.insertEmployee(employee);
		System.out.println("employee inserted");
		break;
		
		case 2:
		
		
		System.out.println("fetching employee");
		System.out.println("enter your id:");
		int empId1=scanner.nextInt();
		Employee emp=service.retriveEmployee(empId1);
		System.out.println(empId1);
		System.out.println("***********************");
		System.out.println("fetching employee");
		//calling service method to fetch employee info
		break;
		case 3: 
	
			System.out.println("thank you");
			System.exit(0);
		}
		
		
		
	}
	}
}

