package com.cap.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class AssertionsTest {
	@Test
	public void test1(){
		String obj1="junit";
		String obj2="junit";
		String obj3="test";
		String obj4="test";
		String obj5=null;
		int var1=1;
		int var2=1;
		int[] arithematic1={1,2,3};
		int[] arithematic2={1,2,3};
		//assertEquals(var1,var2);//checking values
		//assertSame(obj3,obj4);//refernces same are not
		//assertNotSame(obj1,obj4);//
		//assertNotNull(obj1);//executes if object is not null else error
		//assertNull(obj5);//executes if object is null or error
	//assertTrue(obj1.equals(obj3));//condition checking
	//assertFalse(obj1.equals(obj3));
		assertArrayEquals(arithematic1,arithematic2);
		
	}

}
