package com.cap.junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class Test2 {
	@Before
	public void m1()
	{
		System.out.println("executes before each @ Test Case");
	}
	@BeforeClass
	public static void m2()
	{
		System.out.println("executes only one time and first");
	}
	@Test
	public void m3()
	{
		System.out.println(" Test Case1");
	}
	@After
	public void m4()
	{
		System.out.println("executes after each @ Test Case");
	}
	@AfterClass
	public static void m5()
	{
		System.out.println("executes only one timwe and last");
	}
	@Test
	public void m6()
	{
		System.out.println(" Test Case2");
	}
	@Ignore
	public void m7()
	{
		System.out.println("it will ignore by j unit compiller");
	}
	
	
}
