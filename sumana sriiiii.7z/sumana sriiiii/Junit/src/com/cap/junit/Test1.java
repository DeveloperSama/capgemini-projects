package com.cap.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test1 {
	Add t=new Add();
	int i=t.sum(1220,20);//140
	int j=1240;//expected results

	@Test
	public void testsum() {
		System.out.println("sum is : "+i +"="+j);
		assertEquals(i,j);
	}

}

